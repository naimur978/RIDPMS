package com.naimur978.ridpms;

import android.view.View;

/**
 * Created by muhammadriyaz on 23/07/15.
 */
public interface CustomItemClickListener {
    public void onItemClick(View v, int position);
}
